# 📱 GUIDE D'INSTALLATION — CHATBOT WHATSAPP DROGUERIE
## Du zéro au bot actif en 1 heure

---

## CE QU'IL VOUS FAUT

- [ ] Un smartphone avec une SIM dédiée (non utilisée sur WhatsApp)
- [ ] Un PC connecté à Internet
- [ ] 1 heure de votre temps

---

## ÉTAPE 1 — Créer le compte Meta Developer (15 min)

1. Allez sur **https://developers.facebook.com**
2. Cliquez **Se connecter** (avec votre Facebook perso, c'est normal)
3. Cliquez **Mes apps** → **Créer une app**
4. Choisissez **Entreprise** → Suivant
5. Donnez un nom : `Droguerie Al Amal Bot`
6. Cliquez **Créer l'app**

---

## ÉTAPE 2 — Configurer WhatsApp Business (10 min)

1. Dans votre app Meta, cherchez **WhatsApp** dans les produits → cliquez **Configurer**
2. Cliquez **Commencer** dans la section API Setup
3. Notez ces 2 informations importantes :
   - **Phone Number ID** (exemple : `123456789012345`)
   - **Token d'accès temporaire** (commence par `EAAG...`)
4. Pour un token permanent :
   - Allez dans **Paramètres système** → **Utilisateurs système**
   - Créez un utilisateur système → Générez un token → Sélectionnez `whatsapp_business_messaging`
   - Copiez le token et conservez-le précieusement

---

## ÉTAPE 3 — Lier votre numéro de téléphone (10 min)

1. Dans l'API Setup, cliquez **Ajouter un numéro de téléphone**
2. Entrez votre numéro SIM dédié avec indicatif (+212...)
3. Choisissez la vérification par **SMS** ou **appel**
4. Entrez le code reçu → Votre numéro est maintenant lié ✅

> ⚠️ Ce numéro ne pourra plus être utilisé sur WhatsApp normal.
> Utilisez une SIM dédiée uniquement pour le bot.

---

## ÉTAPE 4 — Déployer le serveur sur Railway (10 min)

### 4a. Créer un compte Railway
1. Allez sur **https://railway.app**
2. Connectez-vous avec GitHub (créez un compte GitHub si nécessaire)

### 4b. Déployer le bot
1. Créez un nouveau projet → **Deploy from GitHub repo**
   - OU utilisez **Deploy from template** si vous uploadez les fichiers
2. Uploadez les fichiers du dossier `whatsapp-bot/`
3. Railway détecte automatiquement Node.js

### 4c. Configurer les variables d'environnement
Dans Railway → onglet **Variables**, ajoutez :

| Variable | Valeur |
|---|---|
| `VERIFY_TOKEN` | `mon_token_secret_2024` (votre choix) |
| `WA_TOKEN` | Votre token Meta (EAAG...) |
| `PHONE_ID` | Votre Phone Number ID |
| `ADMIN_PHONE` | `212XXXXXXXXX` (votre numéro sans +) |
| `SHOP_NAME` | `Droguerie Al Amal` |
| `BASE_URL` | L'URL Railway de votre app (ex: https://xxx.railway.app) |

4. Cliquez **Deploy** → Railway vous donne une URL publique

---

## ÉTAPE 5 — Connecter le webhook Meta (10 min)

1. Retournez sur **developers.facebook.com** → votre app → **WhatsApp** → **Configuration**
2. Dans **Webhooks**, cliquez **Modifier**
3. Entrez :
   - **URL de rappel** : `https://VOTRE_URL_RAILWAY.railway.app/webhook`
   - **Token de vérification** : `mon_token_secret_2024` (le même que dans .env)
4. Cliquez **Vérifier et enregistrer**
   - Si ✅ vert → parfait !
   - Si ❌ erreur → vérifiez que Railway est bien démarré
5. Sous **Champs webhook**, abonnez-vous à **messages**

---

## ÉTAPE 6 — Tester le bot (5 min)

1. Depuis votre WhatsApp personnel, envoyez `Bonjour` au numéro du bot
2. Vous devriez recevoir le menu de bienvenue automatiquement
3. Vous recevrez aussi une notification sur votre propre WhatsApp admin

### Si ça ne fonctionne pas :
- Vérifiez les logs Railway (onglet **Logs**)
- Vérifiez que le webhook est bien abonné à `messages`
- Vérifiez que le token est correct

---

## ÉTAPE 7 — Personnaliser votre catalogue

Modifiez le fichier `data/produits.csv` :

```
id;nom;description;prix;prix_promo;stock;photo;categorie
1;Dettol 500ml;Antiseptique;28.50;;oui;dettol.jpg;Désinfectants
```

**Colonnes :**
- `id` : numéro unique
- `nom` : nom du produit (max 24 caractères)
- `description` : courte description
- `prix` : prix normal en MAD (ex: 28.50)
- `prix_promo` : prix promotionnel (laisser vide si pas de promo)
- `stock` : `oui` ou `non`
- `photo` : nom du fichier image dans le dossier `/uploads/` (optionnel)
- `categorie` : catégorie pour regrouper les produits

### Ajouter des photos :
- Uploadez vos photos via `POST /admin/upload` (taille max : 5MB)
- OU utilisez l'outil Railway → Files Manager
- Mettez le nom du fichier dans la colonne `photo` du CSV

---

## COMMANDES UTILES

Voir les commandes reçues :
```
https://VOTRE_URL.railway.app/admin/commandes
```

Voir les produits chargés :
```
https://VOTRE_URL.railway.app/admin/produits
```

Recharger le CSV sans redémarrer :
```
POST https://VOTRE_URL.railway.app/admin/reload
```

---

## FONCTIONNEMENT DU BOT

Le client envoie n'importe quel message → reçoit le menu

**Menu principal :**
- 📦 Catalogue → liste des produits par catégorie
- 🏷️ Promotions → produits en promo
- 🛒 Mon panier → voir et confirmer la commande
- 🚚 Livraison → infos livraison

**Processus de commande :**
1. Client choisit un produit
2. Bot affiche photo + prix + description
3. Client commande → entre la quantité
4. Client valide le panier → entre l'adresse
5. ✅ Confirmation envoyée au client
6. 🔔 Notification envoyée à votre numéro admin

---

## COÛTS ESTIMÉS

| Service | Coût |
|---|---|
| Railway (hébergement) | Gratuit jusqu'à 500h/mois |
| Meta WhatsApp API | Gratuit jusqu'à 1000 conversations/mois |
| Au-delà | ~0.04$ par conversation |

**Pour une petite droguerie → coût = 0 MAD/mois** ✅

---

## SUPPORT

En cas de problème, consultez :
- https://developers.facebook.com/docs/whatsapp
- https://docs.railway.app
